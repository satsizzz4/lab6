package com.glearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DebateRegistrationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DebateRegistrationSystemApplication.class, args);
	}

}
